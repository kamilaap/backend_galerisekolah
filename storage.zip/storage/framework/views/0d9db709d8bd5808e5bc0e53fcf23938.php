<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link rel="shortcut icon" type="image/jpg"
        href="https://smkn4bogor.sch.id/assets/images/logo/logoSMKN4.svg" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>SMKN 4 Kota Bogor</title>
    <!-- Font Awesome CDN -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Flowbite -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.js"></script>
    <!-- AOS CSS -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <style>
           /* Pastikan gambar dan teks terpisah sesuai dengan desain */
 /* Kontainer animasi untuk menjaga agar teks bergerak penuh dari luar layar */
 @keyframes marquee {
    0% {
        transform: translateX(100%);
    }
    100% {
        transform: translateX(-100%);
    }
}

.animate-marquee {
    animation: marquee 30s linear infinite;
}

.animate-marquee:hover {
    animation-play-state: paused;
}



        /* Ukuran gambar informasi */
        .informasi-item img {
            width: 100%;
            height: 400px;
            /* Menambah tinggi gambar menjadi 400px */
            object-fit: cover;
        }
        /* Slider CSS */
.swiper-container {
    height: 700px; /* Atur tinggi slider sesuai kebutuhan, lebih besar dari sebelumnya */
}

.swiper-slide img {
    width: 100%;
    height: 100%; /* Pastikan gambar memenuhi area slider */
    object-fit: cover; /* Memastikan gambar terpotong dengan proporsional */
}
.btn-view-gallery {
    display: inline-block;
    padding: 10px 20px;
    background-color: #40534c; /* Warna sesuai dengan palet */
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.btn-view-gallery:hover {
    background-color: #1a3636; /* Warna saat hover */
}

        /* Tambahkan style untuk efek hover dan animasi */
        .hover-scale {
            transition: transform 0.3s ease;
        }

        .hover-scale:hover {
            transform: scale(1.05);
        }

        .gradient-text {
            background: linear-gradient(45deg, #4F46E5, #2563EB);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .card-shadow {
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            transition: box-shadow 0.3s ease;
        }

        .card-shadow:hover {
            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }

        /* Efek parallax untuk banner */
        .parallax {
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        /* Animasi untuk counter */
        @keyframes countUp {
            from {
                transform: translateY(20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .counter {
            animation: countUp 1s ease-out forwards;
        }

        /* Tambahkan style untuk background dan efek visual */
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8eb 100%);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background shapes */
        .bg-shapes {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            pointer-events: none;
        }

        .bg-shape {
            position: absolute;
            background: linear-gradient(45deg, #4F46E5, #2563EB);
            border-radius: 50%;
            opacity: 0.05;
            animation: float 20s infinite;
        }

        .bg-shape:nth-child(1) {
            width: 300px;
            height: 300px;
            top: -150px;
            left: -150px;
            animation-delay: 0s;
        }

        .bg-shape:nth-child(2) {
            width: 200px;
            height: 200px;
            top: 50%;
            right: -100px;
            animation-delay: -5s;
        }

        .bg-shape:nth-child(3) {
            width: 250px;
            height: 250px;
            bottom: -125px;
            left: 30%;
            animation-delay: -10s;
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0) rotate(0deg);
            }
            25% {
                transform: translateY(-20px) rotate(5deg);
            }
            50% {
                transform: translateY(0) rotate(0deg);
            }
            75% {
                transform: translateY(20px) rotate(-5deg);
            }
        }

        /* Card styling improvements */
        .card-shadow {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        /* Section backgrounds */
        section {
            position: relative;
            overflow: hidden;
        }

        section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(79, 70, 229, 0.05) 0%, rgba(37, 99, 235, 0.05) 100%);
            z-index: -1;
        }

        /* Navbar improvement */
        .navbar-blur {
            background: rgba(17, 24, 39, 0.8);
            backdrop-filter: blur(10px);
        }

        /* Footer improvement */
        footer {
            background: linear-gradient(to right, #1e3a8a, #1e40af);
            position: relative;
            overflow: hidden;
        }

        footer::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 45%, rgba(255,255,255,0.1) 48%, rgba(255,255,255,0.1) 52%, transparent 55%);
            background-size: 200% 200%;
            animation: shine 10s linear infinite;
        }

        @keyframes shine {
            to {
                background-position: 200% 200%;
            }
        }

        /* Swiper custom styles */
        .informasiSwiper {
            padding: 20px 0 40px 0;
        }

        .informasiSwiper .swiper-button-next,
        .informasiSwiper .swiper-button-prev {
            width: 40px;
            height: 40px;
            background-color: white;
            border-radius: 50%;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }

        .informasiSwiper .swiper-button-next:hover,
        .informasiSwiper .swiper-button-prev:hover {
            background-color: #f8fafc;
            transform: scale(1.1);
        }

        .informasiSwiper .swiper-pagination-bullet {
            width: 10px;
            height: 10px;
            background-color: #e2e8f0;
            opacity: 1;
            transition: all 0.3s ease;
        }

        .informasiSwiper .swiper-pagination-bullet-active {
            background-color: #3b82f6;
            width: 24px;
            border-radius: 5px;
        }

        /* Hover effects for cards */
        .informasiSwiper .swiper-slide {
            transition: transform 0.3s ease;
        }

        .informasiSwiper .swiper-slide:hover {
            transform: translateY(-5px);
        }
    </style>
</head>

<body class="bg-gray-100 text-gray-800">
    <div class="bg-shapes">
        <div class="bg-shape"></div>
        <div class="bg-shape"></div>
        <div class="bg-shape"></div>
    </div>

    <!-- Navbar -->
    <nav class="navbar-blur sticky top-0 z-50">
        <div class="container mx-auto px-4">
            <!-- Desktop Navbar -->
            <div class="flex justify-between items-center h-20">
                <!-- Logo dan Nama -->
                <div class="flex items-center space-x-4">
                    <img src="https://smkn4bogor.sch.id/assets/images/logo/logoSMKN4.svg"
                         alt="Logo SMKN 4 Bogor"
                         class="h-12 w-auto hover:scale-105 transition-transform duration-300">
                    <div>
                        <a href="<?php echo e(route('welcome')); ?>"
                           class="text-white font-bold text-xl hover:text-yellow-300 transition-colors duration-300">
                            SMK INDONESIA DIGITAL
                        </a>
                        <p class="text-blue-200 text-sm">Unggul dalam Digital, Berkarakter dalam Akhlak</p>
                    </div>
                </div>

                <!-- Search Bar -->
                <form id="search-form" action="<?php echo e(route('search')); ?>" method="GET"
                      class="hidden md:flex items-center">
                    <div class="relative">
                        <input type="text" name="query"
                               placeholder="Cari informasi..."
                               class="bg-blue-800/50 text-white placeholder-blue-300 px-6 py-2 rounded-full w-64 focus:w-80 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-yellow-400">
                        <button type="submit"
                                class="absolute right-3 top-1/2 transform -translate-y-1/2 text-blue-300 hover:text-yellow-400 transition-colors duration-300">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>

                <!-- Navigation Links -->
                <div class="hidden md:flex items-center space-x-8">
                    <a href="<?php echo e(route('web.informasi.index')); ?>"
                       class="text-white group flex items-center space-x-2 hover:text-yellow-300 transition-all duration-300">
                        <i class="fas fa-info-circle transform group-hover:scale-110 transition-transform"></i>
                        <span>Informasi</span>
                    </a>
                    <a href="<?php echo e(route('web.agenda.index')); ?>"
                       class="text-white group flex items-center space-x-2 hover:text-yellow-300 transition-all duration-300">
                        <i class="fas fa-calendar-alt transform group-hover:scale-110 transition-transform"></i>
                        <span>Agenda</span>
                    </a>
                    <a href="<?php echo e(route('web.galery.index')); ?>"
                       class="text-white group flex items-center space-x-2 hover:text-yellow-300 transition-all duration-300">
                        <i class="fas fa-images transform group-hover:scale-110 transition-transform"></i>
                        <span>Galeri</span>
                    </a>

                    <!-- Auth Buttons/Menu -->
                    <?php if(auth()->guard()->check()): ?>
                        <div class="relative group">
                            <button class="flex items-center space-x-2 text-white hover:text-yellow-300 transition-colors duration-300">
                                <?php if(auth()->user()->avatar): ?>
                                    <img src="<?php echo e(asset(auth()->user()->avatar)); ?>"
                                         alt="Profile"
                                         class="w-8 h-8 rounded-full border-2 border-white object-cover">
                                <?php else: ?>
                                    <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode(auth()->user()->name)); ?>&background=random"
                                         alt="Profile"
                                         class="w-8 h-8 rounded-full border-2 border-white">
                                <?php endif; ?>
                                <span><?php echo e(auth()->user()->name); ?></span>
                                <i class="fas fa-chevron-down text-sm group-hover:rotate-180 transition-transform duration-300"></i>
                            </button>
                            <!-- Dropdown Menu -->
                            <div class="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl py-2 invisible group-hover:visible opacity-0 group-hover:opacity-100 transition-all duration-300">
                                <?php if(auth()->user()->role === 'admin'): ?>
                                    <a href="<?php echo e(route('admin.dashboard.index')); ?>"
                                       class="block px-4 py-2 text-gray-800 hover:bg-blue-50 hover:text-blue-600 transition-colors duration-300">
                                        <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('web.profile')); ?>"
                                       class="block px-4 py-2 text-gray-800 hover:bg-blue-50 hover:text-blue-600 transition-colors duration-300">
                                        <i class="fas fa-user-circle mr-2"></i>Profile
                                    </a>
                                <?php endif; ?>
                                <form action="<?php echo e(route('logout')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                            class="w-full text-left px-4 py-2 text-gray-800 hover:bg-blue-50 hover:text-blue-600 transition-colors duration-300">
                                        <i class="fas fa-sign-out-alt mr-2"></i>Logout
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>"
                           class="bg-yellow-400 text-blue-900 px-6 py-2 rounded-full font-semibold hover:bg-yellow-300 transform hover:scale-105 transition-all duration-300 shadow-lg">
                            Login
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Mobile Menu Button -->
                <button class="md:hidden text-white hover:text-yellow-300 transition-colors duration-300">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
            </div>
        </div>
    </nav>




    <!-- Banner Slider Section -->
    <section class="relative parallax">
        <div class="absolute inset-0 bg-gradient-to-r from-blue-900/70 to-black/70 z-10"></div>
        <div class="absolute inset-0 flex items-center justify-center z-20">
            <div data-aos="fade-up" data-aos-duration="1000">
                <h1 class="text-5xl font-bold text-white text-center mb-4">
                    Selamat Datang Di SMKN 4 Kota Bogor
                </h1>
                <p class="text-xl text-white/90 text-center">
                    Membangun Generasi Digital yang Unggul dan Berkarakter
                </p>
            </div>
        </div>
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <a href="<?php echo e($slider->link); ?>" target="_blank">
                        <img src="<?php echo e($slider->image); ?>" alt="Slider Image">
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </section>

   <!-- Scrolling Title for Informasi Terbaru -->
<div class="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-8 relative overflow-hidden rounded-lg shadow-xl my-6">
    <!-- Header dengan waktu -->
    <div class="absolute top-0 left-1/2 transform -translate-x-1/2 bg-white text-gray-800 px-8 py-3 rounded-b-xl shadow-lg">
        <div class="flex items-center space-x-2">
            <i class="fas fa-clock text-blue-600"></i>
            <p class="font-semibold"><?php echo e(\Carbon\Carbon::now()->setTimezone('Asia/Jakarta')->locale('id')->translatedFormat('l, d F Y H:i')); ?> WIB</p>
        </div>
    </div>

    <!-- Label Informasi Terkini -->
    <div class="container mx-auto px-4 pt-12">
        <div class="flex items-center justify-center mb-4">
            <div class="bg-yellow-400 text-blue-900 px-6 py-2 rounded-full shadow-lg flex items-center space-x-2">
                <i class="fas fa-newspaper text-xl"></i>
                <span class="font-bold text-lg">INFORMASI TERKINI</span>
            </div>
        </div>

        <!-- Scrolling Content -->
        <div class="overflow-hidden w-full">
            <div class="whitespace-nowrap animate-marquee">
                <div class="inline-flex items-center space-x-8">
                    <?php $__currentLoopData = $informasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="inline-flex items-center space-x-2 bg-white/10 px-4 py-2 rounded-full">
                        <i class="fas fa-arrow-right text-yellow-400"></i>
                        <a href="<?php echo e(route('web.informasi.show', $info->id)); ?>"
                           class="text-lg font-semibold hover:text-yellow-300 transition duration-300">
                            <?php echo e($info->judul); ?>

                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <!-- Quick Links -->
        <div class="flex justify-center mt-6 space-x-4">
            <a href="<?php echo e(route('web.informasi.index')); ?>"
               class="bg-white text-blue-600 px-4 py-2 rounded-full hover:bg-yellow-400 hover:text-blue-900 transition duration-300 flex items-center space-x-2 shadow-lg">
                <i class="fas fa-list"></i>
                <span>Lihat Semua Informasi</span>
            </a>
        </div>
    </div>

    <!-- Background Decoration -->
    <div class="absolute -right-10 top-1/2 transform -translate-y-1/2 opacity-10">
        <i class="fas fa-newspaper text-9xl"></i>
    </div>
    <div class="absolute -left-10 top-1/2 transform -translate-y-1/2 opacity-10">
        <i class="fas fa-bullhorn text-9xl"></i>
    </div>
</div>


  <!-- Galery Section -->
<!-- Galery Section -->
<section class="my-16 px-8" data-aos="fade-up">
    <div class="container mx-auto">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold mb-4 gradient-text">Galeri Terbaru</h2>
            <p class="text-gray-600">Dokumentasi kegiatan dan momen berharga SMKN 4 Bogor</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="relative bg-white rounded-xl overflow-hidden card-shadow group transform hover:-translate-y-2 transition-all duration-300">
                <!-- Image Container -->
                <div class="relative h-64 overflow-hidden">
                    <img src="<?php echo e($photo->image); ?>"
                         alt="<?php echo e($photo->judul); ?>"
                         class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500">

                    <!-- Overlay Gradient -->
                    <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                    <!-- Stats Container -->
                    <div class="absolute top-4 right-4 flex flex-col space-y-2">
                        <!-- Comments Counter -->
                        <div class="bg-white/90 backdrop-blur text-gray-800 text-xs font-semibold rounded-full px-3 py-1 shadow-lg flex items-center space-x-1">
                            <i class="fas fa-comment text-blue-500"></i>
                            <span><?php echo e($photo->comments_count ?? 0); ?></span>
                        </div>

                        <!-- Views Counter -->
                        <div class="bg-white/90 backdrop-blur text-gray-800 text-xs font-semibold rounded-full px-3 py-1 shadow-lg flex items-center space-x-1">
                            <i class="fas fa-eye text-green-500"></i>
                            <span><?php echo e($photo->views->count()); ?></span>
                        </div>

                        <!-- Likes Counter -->
                        <div class="bg-white/90 backdrop-blur text-gray-800 text-xs font-semibold rounded-full px-3 py-1 shadow-lg flex items-center space-x-1">
                            <i class="fas fa-heart text-red-500"></i>
                            <span><?php echo e($photo->likes_count); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Content -->
                <div class="p-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-2 group-hover:text-blue-600 transition-colors">
                        <?php echo e($photo->judul); ?>

                    </h3>
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-500">
                            <i class="far fa-calendar-alt mr-1"></i>
                            <?php echo e($photo->created_at->format('d M Y')); ?>

                        </span>
                        <a href="<?php echo e(route('web.galery.photo', $photo->id)); ?>"
                           class="inline-flex items-center text-blue-600 hover:text-blue-700 text-sm font-medium">
                            Lihat Detail
                            <i class="fas fa-arrow-right ml-1 transform group-hover:translate-x-1 transition-transform"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- View All Button -->
        <div class="mt-12 text-center">
            <a href="<?php echo e(route('web.galery.index')); ?>"
               class="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 transform hover:scale-105 transition-all duration-300 shadow-lg">
                <span class="mr-2">Lihat Semua Galeri</span>
                <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>
</section>

<!-- Tambahkan setelah section Galeri -->
<section class="py-12 bg-gradient-to-r from-blue-900 to-blue-800">
    <div class="container mx-auto px-4">
        <div class="text-center mb-8">
            <h2 class="text-3xl font-bold text-white mb-2">Tag Populer</h2>
            <p class="text-blue-200">Tag yang sering digunakan dalam postingan</p>
        </div>

        <div class="flex flex-wrap justify-center gap-4">
            <?php
                $popularTags = \App\Models\Tag::withCount(['informasi', 'agenda', 'galeries'])
                    ->having('informasi_count', '>', 0)
                    ->orHaving('agenda_count', '>', 0)
                    ->orHaving('galeries_count', '>', 0)
                    ->orderByRaw('(informasi_count + agenda_count + galeries_count) DESC')
                    ->limit(10)
                    ->get();
            ?>

            <?php $__currentLoopData = $popularTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $totalUses = $tag->informasi_count + $tag->agenda_count + $tag->galeries_count;
                ?>
                <div class="group relative">
                    <a href="<?php echo e(route('search', ['tag' => $tag->slug])); ?>"
                       class="inline-flex items-center px-6 py-2 bg-white/10 text-white rounded-full hover:bg-white/20 transition-all duration-300">
                        <span class="text-lg">#<?php echo e($tag->name); ?></span>
                        <span class="ml-2 bg-white/20 px-2 py-0.5 rounded-full text-sm">
                            <?php echo e($totalUses); ?>

                        </span>
                    </a>
                    <!-- Tooltip -->
                    <div class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-1 bg-white text-gray-800 text-sm rounded shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 whitespace-nowrap">
                        <div class="text-xs">
                            <?php if($tag->informasi_count > 0): ?>
                                <span class="mr-2">Informasi: <?php echo e($tag->informasi_count); ?></span>
                            <?php endif; ?>
                            <?php if($tag->agenda_count > 0): ?>
                                <span class="mr-2">Agenda: <?php echo e($tag->agenda_count); ?></span>
                            <?php endif; ?>
                            <?php if($tag->galeries_count > 0): ?>
                                <span>Galeri: <?php echo e($tag->galeries_count); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 w-2 h-2 bg-white rotate-45"></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Tag Categories -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            <!-- Informasi Tags -->
            <div class="bg-white/10 backdrop-blur p-6 rounded-xl">
                <h3 class="text-lg font-semibold text-white mb-4 flex items-center">
                    <i class="fas fa-info-circle mr-2"></i>
                    Tag Informasi
                </h3>
                <div class="flex flex-wrap gap-2">
                    <?php $__currentLoopData = $popularTags->where('informasi_count', '>', 0)->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('search', ['tag' => $tag->slug, 'type' => 'informasi'])); ?>"
                           class="px-3 py-1 bg-white/10 text-white rounded-full text-sm hover:bg-white/20 transition-colors">
                            #<?php echo e($tag->name); ?>

                            <span class="text-xs">(<?php echo e($tag->informasi_count); ?>)</span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Agenda Tags -->
            <div class="bg-white/10 backdrop-blur p-6 rounded-xl">
                <h3 class="text-lg font-semibold text-white mb-4 flex items-center">
                    <i class="fas fa-calendar-alt mr-2"></i>
                    Tag Agenda
                </h3>
                <div class="flex flex-wrap gap-2">
                    <?php $__currentLoopData = $popularTags->where('agenda_count', '>', 0)->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('search', ['tag' => $tag->slug, 'type' => 'agenda'])); ?>"
                           class="px-3 py-1 bg-white/10 text-white rounded-full text-sm hover:bg-white/20 transition-colors">
                            #<?php echo e($tag->name); ?>

                            <span class="text-xs">(<?php echo e($tag->agenda_count); ?>)</span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Galeri Tags -->
            <div class="bg-white/10 backdrop-blur p-6 rounded-xl">
                <h3 class="text-lg font-semibold text-white mb-4 flex items-center">
                    <i class="fas fa-images mr-2"></i>
                    Tag Galeri
                </h3>
                <div class="flex flex-wrap gap-2">
                    <?php $__currentLoopData = $popularTags->where('galeries_count', '>', 0)->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('search', ['tag' => $tag->slug, 'type' => 'galeri'])); ?>"
                           class="px-3 py-1 bg-white/10 text-white rounded-full text-sm hover:bg-white/20 transition-colors">
                            #<?php echo e($tag->name); ?>

                            <span class="text-xs">(<?php echo e($tag->galeries_count); ?>)</span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
    <!-- Informasi and Agenda Section -->
    <div class="container mx-auto py-8 flex flex-col md:flex-row gap-6">
      <!-- Informasi Section -->
<div class="md:w-2/3">
    <div class="bg-white shadow-lg rounded-lg p-6">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold gradient-text">Informasi Terbaru</h2>
            <a href="<?php echo e(route('web.informasi.index')); ?>"
               class="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all duration-300 transform hover:scale-105 shadow-md">
                <span>Baca Selengkapnya</span>
                <i class="fas fa-arrow-right ml-2"></i>
            </a>
        </div>

        <!-- Swiper Container -->
        <div class="swiper informasiSwiper">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $informasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <div class="bg-white rounded-lg shadow-md overflow-hidden transform transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
                        <div class="relative">
                            <img src="<?php echo e($info->image); ?>"
                                 alt="<?php echo e($info->judul); ?>"
                                 class="w-full h-48 object-cover">
                            <!-- Overlay gradient -->
                            <div class="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                            <!-- Date badge -->
                            <div class="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-sm font-semibold shadow-lg">
                                <i class="far fa-calendar-alt text-blue-600 mr-1"></i>
                                <?php echo e($info->created_at->format('d M Y')); ?>

                            </div>
                        </div>

                        <div class="p-6">
                            <h3 class="text-xl font-bold mb-3 hover:text-blue-600 transition-colors">
                                <?php echo e($info->judul); ?>

                            </h3>
                            <p class="text-gray-600 mb-4 line-clamp-2">
                                <?php echo e(Str::limit($info->deskripsi, 100)); ?>

                            </p>

                            <!-- Hashtags -->
                            <?php if($info->hashtags->count() > 0): ?>
                            <div class="flex flex-wrap gap-2 mb-4">
                                <?php $__currentLoopData = $info->hashtags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hashtag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('hashtag.show', $hashtag->name)); ?>"
                                   class="px-3 py-1 bg-blue-100 text-blue-600 rounded-full text-sm hover:bg-blue-200 transition-colors">
                                    #<?php echo e($hashtag->name); ?>

                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>

                            <!-- Read More Button -->
                            <div class="flex justify-end">
                                <a href="<?php echo e(route('web.informasi.show', $info->id)); ?>"
                                   class="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium group">
                                    <span>Baca selengkapnya</span>
                                    <i class="fas fa-arrow-right ml-2 transform group-hover:translate-x-1 transition-transform"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- Navigation buttons -->
            <div class="swiper-button-next after:content-['']">
                <i class="fas fa-chevron-right text-blue-600"></i>
            </div>
            <div class="swiper-button-prev after:content-['']">
                <i class="fas fa-chevron-left text-blue-600"></i>
            </div>
            <!-- Pagination -->
            <div class="swiper-pagination"></div>
        </div>
    </div>
</div>

          <!-- Agenda Sekolah Section -->
<div class="md:w-1/3 bg-white rounded-xl p-8 card-shadow" data-aos="fade-left">
    <h2 class="text-xl font-bold mb-4 text-center">Agenda Sekolah</h2>
    <div class="space-y-4">
        <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-blue-50 border border-blue-300 rounded-lg p-4">
            <h3 class="font-semibold text-lg text-blue-700 mb-2"><?php echo e($item->judul); ?></h3>
            <p class="text-sm text-gray-500 mb-1">Tanggal: <?php echo e($item->tanggal); ?></p>
            <p class="text-gray-600 mb-2"><?php echo e(Str::limit($item->deskripsi, 100)); ?></p>
            <a href="<?php echo e(route('web.agenda.show', $item->id)); ?>" class="inline-block bg-blue-500 text-white px-3 py-1 rounded-lg text-sm hover:bg-blue-600 transition duration-200">Detail</a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


    </div>
    <!-- Google Maps Section -->
<section id="maps" class="py-4 -mt-2"> <!-- Mengurangi jarak dari navbar -->
    <div class="w-full h-80"> <!-- Tinggi peta lebih kecil -->
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31722.047149155723!2d106.815542!3d-6.6407334!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69c8b16ee07ef5%3A0x14ab253dd267de49!2sSMK%20Negeri%204%20Bogor%20(Nebrazka)!5e0!3m2!1sid!2sid!4v1693082189497!5m2!1sid!2sid"
            width="100%"
            height="100%"
            style="border:0;"
            allowfullscreen=""
            loading="lazy">
        </iframe>
    </div>
</section>

  <!-- Footer -->
<footer class="bg-gray-800 text-white py-8">
    <div class="container mx-auto text-center">
        <div class="mb-4">
            <img src="https://smkn4bogor.sch.id/assets/images/logo/logoSMKN4.svg" alt="Logo SMKN 4 Bogor" class="h-12 mx-auto">
        </div>
        <p class="text-sm mb-2">
            SMKN 4 Bogor, Jl. Raya Tajur, Kp. Buntar RT.02/RW.08, Kel. Muara Sari, Kec. Bogor Selatan, Kota Bogor, Jawa Barat 16137
        </p>
        <p class="text-sm">
            © 2024 SMKN 4 Bogor. All rights reserved.
        </p>

        <!-- Media Sosial dan Email -->
        <div class="flex justify-center space-x-6 mt-6">
            <a href="https://web.facebook.com/people/SMK-NEGERI-4-KOTA-BOGOR/100054636630766/" class="text-gray-400 hover:text-blue-600" aria-label="Facebook" target="_blank">
                <i class="fab fa-facebook-f"></i>
            </a>
            <a href="https://www.instagram.com/smkn4kotabogor/" class="text-gray-400 hover:text-pink-500" aria-label="Instagram" target="_blank">
                <i class="fab fa-instagram"></i>
            </a>
            <a href="https://twitter.com" class="text-gray-400 hover:text-blue-400" aria-label="Twitter" target="_blank">
                <i class="fab fa-twitter"></i>
            </a>
            <a href="https://www.youtube.com/@smknegeri4bogor905" class="text-gray-400 hover:text-red-500" aria-label="YouTube" target="_blank">
                <i class="fab fa-youtube"></i>
            </a>
            <a href="mailto:smkn4@smkn4bogor.sch.id" class="text-gray-400 hover:text-yellow-400" aria-label="Email">
                <i class="fas fa-envelope"></i>
            </a>
        </div>
    </div>
</footer>

<!-- Font Awesome untuk Ikon -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script>

        // Initialize Swipers with individual configurations if required
        const mainSwiper = new Swiper('.swiper-container', {
            loop: true,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },
        });

        const infoSwiper = new Swiper('.informasi-swiper', {
            slidesPerView: 1,
            spaceBetween: 10,
            loop: true,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        });

       // Function to display current date and time
    function updateDateTime() {
        const now = new Date();
        const options = {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        };
        document.getElementById('currentDateTime').textContent = now.toLocaleDateString('id-ID', options);
    }

    // Update date and time on page load
    document.addEventListener('DOMContentLoaded', () => {
        updateDateTime();
        // Initialize Swipers here if needed
    });

    AOS.init({
        duration: 800,
        once: true
    });

    // Tambahkan smooth scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Initialize Informasi Swiper
    const informasiSwiper = new Swiper('.informasiSwiper', {
        slidesPerView: 1,
        spaceBetween: 30,
        loop: true,
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        effect: 'fade',
        fadeEffect: {
            crossFade: true
        },
        breakpoints: {
            640: {
                slidesPerView: 1,
            },
            768: {
                slidesPerView: 1,
            },
            1024: {
                slidesPerView: 1,
            },
        }
    });

    // Pause autoplay on hover
    const swiperContainer = document.querySelector('.informasiSwiper');
    swiperContainer.addEventListener('mouseenter', () => {
        informasiSwiper.autoplay.stop();
    });
    swiperContainer.addEventListener('mouseleave', () => {
        informasiSwiper.autoplay.start();
    });

    </script>

</body>

</html>
<?php /**PATH C:\Users\Lenovo\OneDrive\Documents\backend_galerisekolah\resources\views/welcome.blade.php ENDPATH**/ ?>