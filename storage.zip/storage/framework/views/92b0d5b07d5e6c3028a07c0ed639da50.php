<?php $__env->startSection('content'); ?>
<div class="flex justify-center items-center h-screen" style="background-color: #9DBDFF;">
    <div class="p-6 max-w-sm w-full" style="background-color: #FFD7C4; box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); border-radius: 8px;">
        <div class="flex justify-center items-center">
            <span style="color: #7695FF; font-weight: bold; font-size: 24px;">UPDATE PASSWORD</span>
        </div>
        <?php if(session('status')): ?>
        <div class="bg-green-500 p-3 rounded-md shadow-sm mt-3">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <form class="mt-4" action="<?php echo e(route('password.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e($request->route('token')); ?>">
            <label class="block mt-3">
                <span style="color: #7695FF;">Email</span>
                <input type="email" name="email" value="<?php echo e($request->email ?? old('email')); ?>" class="form-input mt-1 block w-full rounded-md border-[#7695FF]" placeholder="Alamat Email">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="inline-flex max-w-sm w-full bg-red-200 shadow-sm rounded-md overflow-hidden mt-2">
                    <div class="px-4 py-2">
                        <p class="text-gray-600 text-sm"><?php echo e($message); ?></p>
                    </div>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="block mt-3">
                <span style="color: #7695FF;">Password</span>
                <input type="password" name="password" class="form-input mt-1 block w-full rounded-md border-[#7695FF]" placeholder="Password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="inline-flex max-w-sm w-full bg-red-200 shadow-sm rounded-md overflow-hidden mt-2">
                    <div class="px-4 py-2">
                        <p class="text-gray-600 text-sm"><?php echo e($message); ?></p>
                    </div>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="block mt-3">
                <span style="color: #7695FF;">Konfirmasi Password</span>
                <input type="password" name="password_confirmation" class="form-input mt-1 block w-full rounded-md border-[#7695FF]" placeholder="Konfirmasi Password">
                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="inline-flex max-w-sm w-full bg-red-200 shadow-sm rounded-md overflow-hidden mt-2">
                    <div class="px-4 py-2">
                        <p class="text-gray-600 text-sm"><?php echo e($message); ?></p>
                    </div>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <div class="mt-6">
                <button type="submit" class="py-2 px-4 text-center" style="background-color: #7695FF; color: white; border-radius: 8px; width: 100%;">UPDATE PASSWORD</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', ['title' => 'Update Password - Admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\OneDrive\Documents\backend_galerisekolah\resources\views/auth/reset-password.blade.php ENDPATH**/ ?>