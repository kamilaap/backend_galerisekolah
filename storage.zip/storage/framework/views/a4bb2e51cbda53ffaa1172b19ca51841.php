<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($jurusan->nama); ?> - Detail Jurusan</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8eb 100%);
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Hero Section -->
    <div class="relative bg-blue-900 text-white py-20">
        <div class="container mx-auto px-4 text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4" data-aos="fade-up"><?php echo e($jurusan->nama); ?></h1>

            <!-- Display the first image from the gallery -->
            <?php if($jurusan->photos->isNotEmpty()): ?>
                <img src="<?php echo e($jurusan->photos->first()->image); ?>" alt="<?php echo e($jurusan->nama); ?>" class="w-full h-auto object-cover rounded-lg mb-4">
            <?php endif; ?>

            <p class="text-xl text-blue-100 mb-8" data-aos="fade-up" data-aos-delay="100">
                <?php echo e($jurusan->deskripsi); ?>

            </p>

            <!-- Back Button -->
            <div class="mb-8" data-aos="fade-up" data-aos-delay="200">
                <a href="<?php echo e(route('welcome')); ?>"
                   class="inline-flex items-center px-6 py-3 bg-white/10 text-white rounded-full hover:bg-white/20 transition-all duration-300">
                    <i class="fas fa-arrow-left mr-2"></i>
                    <span>Kembali ke Beranda</span>
                </a>
            </div>
        </div>
    </div>

    <!-- Gallery Section -->
    <div class="container mx-auto px-4 py-12">
        <h2 class="text-2xl font-bold mb-4">Galeri <?php echo e($jurusan->nama); ?></h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php $__currentLoopData = $jurusan->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                    <img src="<?php echo e($photo->image); ?>" alt="<?php echo e($photo->judul); ?>" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <h3 class="text-lg font-semibold"><?php echo e($photo->judul); ?></h3>
                        <p class="text-gray-600"><?php echo e(Str::limit($photo->deskripsi, 100)); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\aplikasisekolah\backend_galerisekolah\resources\views/web/jurusan/show.blade.php ENDPATH**/ ?>