<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Pencarian - <?php echo e($keyword); ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <div class="mb-6">
            <a href="<?php echo e(route('welcome')); ?>" class="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <i class="fas fa-arrow-left mr-2"></i>
                Kembali ke Beranda
            </a>
        </div>

        <h1 class="text-3xl font-bold mb-6">Hasil Pencarian: "<?php echo e($keyword); ?>"</h1>

        <?php if($results['informasi']->count() > 0): ?>
        <div class="mb-8">
            <h2 class="text-2xl font-semibold mb-4">Informasi</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $results['informasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <img src="<?php echo e($info->image); ?>" alt="<?php echo e($info->judul); ?>" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <h3 class="text-lg font-semibold mb-2"><?php echo e($info->judul); ?></h3>
                        <p class="text-gray-600 mb-4"><?php echo e(Str::limit($info->deskripsi, 100)); ?></p>
                        <a href="<?php echo e(route('web.informasi.show', $info->id)); ?>" class="text-blue-600 hover:text-blue-800">
                            Baca selengkapnya
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if($results['agenda']->count() > 0): ?>
        <div class="mb-8">
            <h2 class="text-2xl font-semibold mb-4">Agenda</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $results['agenda']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-md p-4">
                    <div class="flex items-center mb-2">
                        <i class="far fa-calendar-alt text-blue-600 mr-2"></i>
                        <span><?php echo e(date('d M Y', strtotime($item->tanggal))); ?></span>
                    </div>
                    <h3 class="text-lg font-semibold mb-2"><?php echo e($item->judul); ?></h3>
                    <p class="text-gray-600 mb-4"><?php echo e(Str::limit($item->deskripsi, 100)); ?></p>
                    <a href="<?php echo e(route('web.agenda.show', $item->id)); ?>" class="text-blue-600 hover:text-blue-800">
                        Lihat detail
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if($results['galeries']->count() > 0): ?>
        <div class="mb-8">
            <h2 class="text-2xl font-semibold mb-4">Galeri</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $results['galeries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <?php if($galery->photos->first()): ?>
                    <img src="<?php echo e($galery->photos->first()->image); ?>" alt="<?php echo e($galery->judul); ?>" class="w-full h-48 object-cover">
                    <?php endif; ?>
                    <div class="p-4">
                        <h3 class="text-lg font-semibold mb-2"><?php echo e($galery->judul); ?></h3>
                        <p class="text-gray-600 mb-4"><?php echo e(Str::limit($galery->deskripsi, 100)); ?></p>
                        <a href="<?php echo e(route('web.galery.photo', $galery->id)); ?>" class="text-blue-600 hover:text-blue-800">
                            Lihat galeri
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if($results['informasi']->count() === 0 && $results['agenda']->count() === 0 && $results['galeries']->count() === 0): ?>
        <div class="text-center py-8">
            <i class="fas fa-search text-gray-400 text-5xl mb-4"></i>
            <p class="text-gray-600">Tidak ada hasil yang ditemukan untuk "<?php echo e($keyword); ?>"</p>
            <a href="<?php echo e(route('welcome')); ?>" class="inline-block mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Kembali ke Beranda
            </a>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\aplikasisekolah\backend_galerisekolah\resources\views/web/search/results.blade.php ENDPATH**/ ?>