<?php $__env->startSection('content'); ?>
<main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100">
    <div class="container mx-auto px-6 py-8">
        <!-- Header Section -->
        <div class="mb-8">
            <div class="bg-gradient-to-r from-blue-600 to-blue-800 rounded-xl p-8 text-white">
                <div class="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
                    <img src="<?php echo e(auth()->user()->avatar ?? 'https://ui-avatars.com/api/?name='.urlencode(auth()->user()->name)); ?>"
                         alt="Profile"
                         class="w-24 h-24 rounded-full border-4 border-white shadow-lg">
                    <div>
                        <h1 class="text-3xl font-bold"><?php echo e(auth()->user()->name); ?></h1>
                        <p class="text-blue-100">Administrator</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Status Messages -->
        <?php if(session('status')): ?>
        <div class="mb-8">
            <div class="bg-green-500 bg-opacity-90 backdrop-blur-sm text-white p-4 rounded-lg shadow-md">
                <?php if(session('status')=='profile-information-updated'): ?>
                    <div class="flex items-center">
                        <i class="fas fa-check-circle mr-2"></i>
                        <span>Profil berhasil diperbarui</span>
                    </div>
                <?php endif; ?>
                <?php if(session('status')=='password-updated'): ?>
                    <div class="flex items-center">
                        <i class="fas fa-check-circle mr-2"></i>
                        <span>Password berhasil diperbarui</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Content Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Left Column -->
            <div class="space-y-8">
                <!-- Edit Profile Card -->
                <div class="bg-white rounded-xl shadow-md overflow-hidden">
                    <div class="p-6 bg-gradient-to-r from-blue-600 to-blue-800">
                        <h2 class="text-xl font-semibold text-white">Edit Profil</h2>
                    </div>
                    <div class="p-6">
                        <form action="<?php echo e(route('user-profile-information.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <!-- Name -->
                            <div class="mb-6">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Nama Lengkap
                                </label>
                                <input type="text"
                                       name="name"
                                       value="<?php echo e(old('name') ?? auth()->user()->name); ?>"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                       placeholder="Masukkan nama lengkap">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Email -->
                            <div class="mb-6">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Email
                                </label>
                                <input type="email"
                                       name="email"
                                       value="<?php echo e(old('email') ?? auth()->user()->email); ?>"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                       placeholder="Masukkan email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Submit Button -->
                            <button type="submit"
                                    class="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all">
                                <i class="fas fa-save mr-2"></i>
                                Update Profil
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Two Factor Authentication Card -->
                <?php if(Laravel\Fortify\Features::enabled(Laravel\Fortify\Features::twoFactorAuthentication())): ?>
                <div class="bg-white rounded-xl shadow-md overflow-hidden">
                    <div class="p-6 bg-gradient-to-r from-blue-600 to-blue-800">
                        <h2 class="text-xl font-semibold text-white">Autentikasi Dua Faktor</h2>
                    </div>
                    <div class="p-6">
                        <?php if(!auth()->user()->two_factor_secret): ?>
                            <form method="POST" action="<?php echo e(url('user/two-factor-authentication')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                        class="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all">
                                    <i class="fas fa-shield-alt mr-2"></i>
                                    Aktifkan 2FA
                                </button>
                            </form>
                        <?php else: ?>
                            <div class="space-y-6">
                                <?php if(session('status') == 'two-factor-authentication-enabled'): ?>
                                    <div class="text-sm text-gray-600 mb-4">
                                        Scan QR code berikut dengan aplikasi autentikator Anda:
                                    </div>
                                    <div class="flex justify-center mb-6">
                                        <?php echo auth()->user()->twoFactorQrCodeSvg(); ?>

                                    </div>
                                <?php endif; ?>

                                <div class="bg-gray-900 rounded-lg p-4">
                                    <div class="text-sm text-white mb-2">Recovery Codes:</div>
                                    <?php $__currentLoopData = json_decode(decrypt(auth()->user()->two_factor_recovery_codes), true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="text-sm font-mono text-gray-300"><?php echo e($code); ?></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <div class="flex space-x-4">
                                    <form method="POST" action="<?php echo e(url('user/two-factor-recovery-codes')); ?>" class="flex-1">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit"
                                                class="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all">
                                            <i class="fas fa-sync-alt mr-2"></i>
                                            Regenerate Codes
                                        </button>
                                    </form>

                                    <form method="POST" action="<?php echo e(url('user/two-factor-authentication')); ?>" class="flex-1">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                                class="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-all">
                                            <i class="fas fa-shield-alt mr-2"></i>
                                            Nonaktifkan 2FA
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Right Column -->
            <div>
                <!-- Update Password Card -->
                <div class="bg-white rounded-xl shadow-md overflow-hidden">
                    <div class="p-6 bg-gradient-to-r from-blue-600 to-blue-800">
                        <h2 class="text-xl font-semibold text-white">Update Password</h2>
                    </div>
                    <div class="p-6">
                        <form action="<?php echo e(route('user-password.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <!-- Current Password -->
                            <div class="mb-6">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Password Saat Ini
                                </label>
                                <input type="password"
                                       name="current_password"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                       placeholder="Masukkan password saat ini">
                            </div>

                            <!-- New Password -->
                            <div class="mb-6">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Password Baru
                                </label>
                                <input type="password"
                                       name="password"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                       placeholder="Masukkan password baru">
                            </div>

                            <!-- Confirm Password -->
                            <div class="mb-6">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Konfirmasi Password Baru
                                </label>
                                <input type="password"
                                       name="password_confirmation"
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                       placeholder="Konfirmasi password baru">
                            </div>

                            <!-- Submit Button -->
                            <button type="submit"
                                    class="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all">
                                <i class="fas fa-key mr-2"></i>
                                Update Password
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Profile - Admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aplikasisekolah\backend_galerisekolah\resources\views/admin/profile/index.blade.php ENDPATH**/ ?>