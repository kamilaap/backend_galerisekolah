<?php $__env->startSection('content'); ?>
<div class="auth-card w-full max-w-md p-8">
    <div class="text-center mb-8">
        <h1 class="text-2xl font-bold text-gray-800">Reset Password</h1>
        <p class="text-gray-600 mt-2">Enter your email to receive reset instructions</p>
    </div>

    <?php if(session('status')): ?>
    <div class="bg-green-50 text-green-700 p-4 rounded-lg mb-6">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>

    <form action="<?php echo e(route('password.email')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="space-y-5">
            <div>
                <label class="text-sm font-medium text-gray-700 block mb-2">Email Address</label>
                <input type="email"
                       name="email"
                       class="input-field <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('email')); ?>"
                       placeholder="name@company.com">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn-primary">
                Send Reset Link
            </button>

            <div class="text-center mt-4">
                <a href="<?php echo e(route('login')); ?>" class="text-sm text-blue-600 hover:underline">
                    Back to Login
                </a>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', ['title' => 'Forgot Password - Admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\aplikasisekolah\backend_galerisekolah\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>